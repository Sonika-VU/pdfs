package com.example.demo.controller;

import com.example.demo.dto.CustomerProfileDTO;
import com.example.demo.dto.LoanResponseDTO;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.feign.CustomerClient;
import com.example.demo.feign.LoanClient;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private LoanClient loanClient;

    @Autowired
    private CustomerClient customerClient;

    // ==============================
    // Get All Loans
    // ==============================
    @GetMapping("/loans")
    public List<LoanResponseDTO> getAllLoans(HttpServletRequest request) {
        String token = request.getHeader("Authorization");
        return loanClient.getAllLoans(token);
    }

    // ==============================
    // Get Customer Profile For Loan
    // ==============================

    @GetMapping("/customer-profile/{accountNo}")
    public ResponseEntity<CustomerProfileDTO> getCustomerProfileByAccountNo(
            @PathVariable("accountNo") Long accountNo) {

        // Get Customer Profile directly
        CustomerProfileDTO profile = customerClient.getCustomerByAccountNo(accountNo);

        if (profile == null) {
            throw new ResourceNotFoundException("Customer profile not found for Account No: " + accountNo);
        }

        return ResponseEntity.ok(profile);
    }
    // @GetMapping("/customer-profile/{applicationNo}")
    // public ResponseEntity<Map<String, Object>> getCustomerProfileForLoan(
    // @PathVariable Long applicationNo,
    // HttpServletRequest request) {
    //
    // String token = request.getHeader("Authorization");
    //
    // // 1️⃣ Get Loan By ID (Better than filtering all loans)
    // LoanResponseDTO loan =
    // loanClient.getLoanById(applicationNo, token);
    //
    // if (loan == null) {
    // throw new RuntimeException("Loan not found");
    // }
    //
    // // 2️⃣ Call Customer-Service
    // CustomerProfileDTO profile =
    // customerClient.getCustomerByAccountNo(
    // loan.getAccountNo(),
    // token);
    //
    // if (profile == null) {
    // throw new RuntimeException("Customer profile not found");
    // }
    //
    // // 3️⃣ Prepare Response
    // Map<String, Object> response = new HashMap<>();
    // response.put("loanDetails", loan);
    // response.put("customerProfile", profile);
    //
    // return ResponseEntity.ok(response);
    // }

    // ==============================
    // Manual Approve
    // ==============================
    @PutMapping("/approve")
    public LoanResponseDTO approveLoan(
            @RequestParam("applicationId") Long applicationId,
            HttpServletRequest request) {

        String token = request.getHeader("Authorization");

        return loanClient.updateLoanStatus(
                applicationId,
                "APPROVED",
                "Manually approved by Admin",
                token);
    }

    // ==============================
    // Manual Deny
    // ==============================
    @PutMapping("/deny")
    public LoanResponseDTO denyLoan(
            @RequestParam("applicationId") Long applicationId,
            @RequestParam("reason") String reason,
            HttpServletRequest request) {

        String token = request.getHeader("Authorization");

        return loanClient.updateLoanStatus(
                applicationId,
                "DENIED",
                reason,
                token);
    }

    // ==============================
    // Manual Abeyance
    // ==============================
    @PutMapping("/abeyance")
    public LoanResponseDTO abeyanceLoan(
            @RequestParam("applicationId") Long applicationId,
            HttpServletRequest request) {

        String token = request.getHeader("Authorization");

        return loanClient.updateLoanStatus(
                applicationId,
                "ABEYANCE",
                "Placed in Abeyance",
                token);
    }

    @GetMapping("/ping")
    public String ping() {
        return "PONG Admin! Authentication succeeded!";
    }
}