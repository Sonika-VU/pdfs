package com.example.demo.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.example.demo.dto.CustomerProfileDTO;
import com.example.demo.FeignConfig;

@FeignClient(name = "customer-service", url = "http://localhost:8081", configuration = FeignConfig.class)
public interface CustomerClient {

    // @GetMapping("/profile/pan/{pan}")
    // CustomerProfileRespaconseDTO getCustomerProfileByPan(
    // @PathVariable("pan") String pan,
    // @RequestHeader("Authorization") String token);

    @GetMapping("/profile/account/{accountNo}")
    CustomerProfileDTO getCustomerByAccountNo(
            @PathVariable("accountNo") Long accountNo);
    // @RequestHeader("Authorization") String token);

}
