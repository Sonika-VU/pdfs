package com.example.demo.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dto.LoanResponseDTO;
import com.example.demo.FeignConfig;

@FeignClient(name = "loan-service", url = "http://localhost:8898", configuration = FeignConfig.class)
public interface LoanClient {

        // ✅ Update Loan Status (Approve / Deny / Abeyance)
        @PutMapping("/loan/status")
        LoanResponseDTO updateLoanStatus(
                        @RequestParam("applicationId") Long applicationId,
                        @RequestParam("status") String status,
                        @RequestParam(value = "reason", required = false) String reason,
                        @RequestHeader("Authorization") String token);

        // ✅ Get All Loans
        @GetMapping("/loan/all")
        List<LoanResponseDTO> getAllLoans(
                        @RequestHeader("Authorization") String token);

        // ✅ Get Loan By Application ID (THIS IS WHAT YOU ASKED)
        @GetMapping("/loan/{applicationNo}")
        LoanResponseDTO getLoanById(
                        @PathVariable("applicationNo") Long applicationNo);
        // @RequestHeader("Authorization") String token);
}